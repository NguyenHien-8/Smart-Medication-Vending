# Task 1: Return a structured local medical decision

BASE: b3dfb868909370a89ecc4d383ffa5be309906846

Files: `main/medical/medical_advisor.h`, `main/medical/medical_advisor.cc`, `main/medical/tests/test_medical_advisor.cc`, `scripts/tests/run_smartmedivend_host_tests.sh`.

RED: tests require `MedicalDecision`, `MedicalOffer`, `MedicalEvaluation`, and `EvaluateStructured`; verify a single headache option is structured, multiple diarrhoea options refer, forbidden control fields deny, no SKU/channel leaks, and catalog `initial_stock=0` does not suppress clinical eligibility.

GREEN: refactor all evaluator exits into a structured result rendered once; preserve `Evaluate()` compatibility and `vend_allowed=false`; medical evaluation must not use catalog stock.

Verify with the Windows host runner using Visual Studio Build Tools plus bundled cJSON source, because this host has no Bash runtime.
