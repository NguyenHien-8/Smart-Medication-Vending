# Task 2: Bind pharmacist approval to exact embedded artifacts

BASE: b5991b69f871b20eb7663d175e532894343351e7

RED: valid synthetic approval passes; false approval, missing/null identity fields, malformed RFC3339 timestamp, mismatched versions/hashes, invalid hash format, unknown fields, and the current incomplete repository review all fail.

GREEN: add `ArtifactIdentity`, `ReviewResult`, and strict `PharmacistReviewVerifier`; generate exact version and SHA-256 constants at CMake configure time without modifying pharmacist data.

Verification: run the PowerShell host runner; retain the portable Bash command for CI.
