# Task 3: Validate the catalog and route primary/backup stock

BASE: 970c43e40525142047db6ab07ca8a0af916706a3

RED: primary, backup, empty, unknown inventory/item; duplicate channel/primary/backup; bad backup reference; identity mismatches; repository antacid mismatch.

GREEN: add bounded `vending_types.h` and immutable `CatalogRouter`; `Select` accepts only canonical ID plus `StockSnapshot`; ignore catalog `initial_stock`.

Verify using the vending PowerShell host runner and retain the portable Bash runner.
