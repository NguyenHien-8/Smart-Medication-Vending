### Task 1: Verify and commit the existing disconnect, timer, and schema hardening

**Files:**
- Modify: `main/application.cc` (`Initialize`, `Run`, `InitializeProtocol`)
- Modify: `main/application.h` (transport health member and event bit)
- Modify: `main/protocols/websocket_protocol.cc`
- Modify: `main/protocols/websocket_protocol.h`
- Modify: `main/boards/smartmedivend-s3/esp_relay_platform.cc`
- Modify: `main/boards/smartmedivend-s3/esp_relay_platform.h`
- Modify: `main/boards/smartmedivend-s3/smartmedivend_board.cc`
- Modify: `main/vending/catalog_router.cc`
- Create: `main/vending/transport_health_gate.h`
- Create: `main/vending/tests/test_transport_health_gate.cc`
- Create: `main/vending/tests/test_esp_relay_platform.cc`
- Create: `main/vending/tests/esp_host_include/driver/gpio.h`
- Create: `main/vending/tests/esp_host_include/esp_timer.h`
- Create: `main/vending/tests/esp_host_include/freertos/FreeRTOS.h`
- Create: `main/vending/tests/host_include/cJSON.h`
- Create: `scripts/tests/test_smartmedivend_transport_disconnect.py`
- Modify: `main/vending/tests/test_catalog_router.cc`
- Modify: `main/vending/tests/run_host_tests.sh`
- Modify: `main/vending/tests/run_host_tests.ps1`

**Interfaces:**
- Consumes: protocol connect/disconnect callbacks and ESP timer expiration/cancel behavior.
- Produces: `Application::IsTransportOperational()`, stale-reconnect rejection, immutable timer callback leases, and strict current rule-envelope validation.

- [ ] **Step 1: Inspect the existing uncommitted patch and isolate its scope**

Run:

```powershell
git status --short
git diff -- main/application.cc main/application.h main/protocols/websocket_protocol.cc main/protocols/websocket_protocol.h main/boards/smartmedivend-s3/esp_relay_platform.cc main/boards/smartmedivend-s3/esp_relay_platform.h main/boards/smartmedivend-s3/smartmedivend_board.cc main/vending/catalog_router.cc main/vending/tests
```

Expected: only transport gating, timer lease protection, strict rule validation, and their tests are in scope. Keep the ZIP and every unrelated path unstaged.

- [ ] **Step 2: Add the new ESP adapter and transport tests to the PowerShell runner**

Append MSVC compile/run blocks equivalent to:

```powershell
$transportArgs = @("/nologo", "/std:c++20", "/EHsc", "/W4", "/WX",
    "/Imain", "/Imain/vending", "main/vending/tests/test_transport_health_gate.cc",
    "/Fe:$transportExe")
$espRelayArgs = @("/nologo", "/std:c++20", "/EHsc", "/W4", "/WX",
    "/Imain", "/Imain/vending", "/Imain/boards/smartmedivend-s3",
    "/Imain/vending/tests/esp_host_include",
    "main/boards/smartmedivend-s3/esp_relay_platform.cc",
    "main/vending/tests/test_esp_relay_platform.cc", "/Fe:$espRelayExe")
```

Run each executable and throw on a nonzero exit code, matching the existing runner style.

Create a static Python regression that asserts `Application::InitializeProtocol()` registers
`Protocol::OnDisconnected`, MQTT invokes `on_disconnected_` on broker loss, WebSocket invokes it on
unintentional socket loss, and both paths reach the board hook through the application event bit.

- [ ] **Step 3: Run the focused host suites**

Run:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/tests/run_smartmedivend_host_tests.ps1
powershell -ExecutionPolicy Bypass -File main/vending/tests/run_host_tests.ps1
& 'C:\Espressif\python_env\idf6.1_py3.14_env\Scripts\python.exe' -m unittest scripts.tests.test_smartmedivend_transport_disconnect -v
```

Expected: medical, review, catalog, inventory, coordinator, relay, ESP relay platform, and transport health tests pass. Fix only failures caused by these hardening hunks.

- [ ] **Step 4: Build the current development variant with ESP-IDF 6.1**

Run:

```powershell
$env:PYTHONUTF8='1'
$env:PATH='C:\Espressif\tools\python\v6.1\venv\Scripts;' + $env:PATH
. 'C:\esp\v6.1\esp-idf\export.ps1'
& 'C:\Espressif\python_env\idf6.1_py3.14_env\Scripts\python.exe' scripts/build.py smartmedivend-s3 --name smartmedivend-s3
```

Expected: build succeeds and physical vending remains disabled in this variant.

- [ ] **Step 5: Commit only the verified hardening files**

Run `git add` with the exact Task 1 paths, including
`scripts/tests/test_smartmedivend_transport_disconnect.py`, then:

```powershell
git diff --cached --check
git status --short
git commit -m "fix: harden vending transport and timer races"
```

Expected: the ZIP remains untracked and no unrelated file is included.

