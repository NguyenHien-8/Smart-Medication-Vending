### Task 2: Add the immutable boot-time medical policy cache

**Files:**
- Create: `main/medical/medical_policy_cache.h`
- Create: `main/medical/medical_policy_cache.cc`
- Create: `main/medical/tests/test_medical_policy_cache.cc`
- Modify: `data/medical_rules.json` (recognized non-excluding input sentinels and version)
- Modify: `data/medicines.json` (channel-15 identity and catalog version only)
- Modify: `main/vending/catalog_router.cc` (temporary schema compatibility until Task 5)
- Modify: `main/vending/tests/test_catalog_router.cc`
- Modify: `main/CMakeLists.txt` (SmartMediVend source list)
- Modify: `scripts/tests/run_smartmedivend_host_tests.ps1`
- Modify: `scripts/tests/run_smartmedivend_host_tests.sh`

**Interfaces:**
- Consumes: exact embedded rules and catalog bytes.
- Produces: one immutable typed cache with `valid()`, `validation_reason()`, normalized questions/rules/items, and indexed lookups used by later tasks.

- [ ] **Step 1: Write cache tests that fail because the cache does not exist**

Create fixtures around these assertions:

```cpp
smv::MedicalPolicyCache policy(rules, fixed_catalog);
Check(policy.valid(), "valid repository-shaped policy rejected");
Check(policy.artifact_parse_count() == 2, "artifacts were not parsed exactly once");
Check(policy.RulesForSymptom("mild_headache").size() == 1,
      "symptom index missing paracetamol");
Check(policy.FindQuestion("headache_mild") != nullptr,
      "question index missing symptom check");
Check(policy.FindCatalogItem("PARACETAMOL_500")->primary_channel == 0,
      "primary route not normalized");
Check(policy.FindCatalogItem("PARACETAMOL_500")->backup_channel == 13,
      "backup route not normalized");
```

Add mutations that make `valid()` false for null/empty/non-string `symptoms`, `refer_if`, or `exclude_if`; duplicate question IDs; missing symptom profiles; unknown canonical IDs; duplicate/out-of-range channels; unsupported units; primary/backup mismatch; oversized strings/arrays; and trailing JSON bytes.

- [ ] **Step 2: Run the new cache test and verify it fails**

Run:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/tests/run_smartmedivend_host_tests.ps1
```

Expected: compilation fails on `medical/medical_policy_cache.h`.

- [ ] **Step 3: Define bounded policy types and lookups**

Use these public shapes consistently in later tasks:

```cpp
inline constexpr size_t kMaxMedicalRules = 16;
inline constexpr size_t kMaxMedicalQuestions = 64;
inline constexpr size_t kMaxMedicalFlags = 128;
inline constexpr size_t kMaxMedicalSymptoms = 32;

enum class QuestionAction { kRefer, kClarify };

struct PolicyQuestion {
    std::string id;
    std::string question_vi;
    bool expected = false;
    QuestionAction on_mismatch = QuestionAction::kRefer;
    uint16_t priority = 0;
};

struct MedicinePolicy {
    std::string canonical_id;
    std::vector<size_t> symptom_indices;
    std::bitset<kMaxMedicalFlags> refer_flags;
    std::bitset<kMaxMedicalFlags> exclude_flags;
    std::optional<uint8_t> minimum_age_years;
    std::optional<uint16_t> selection_priority;
};

struct PolicyCatalogItem {
    std::string canonical_id;
    std::string name;
    std::string active_ingredient;
    std::string strength;
    std::string primary_sku;
    uint8_t primary_channel = kInvalidVendingChannel;
    std::optional<std::string> backup_sku;
    std::optional<uint8_t> backup_channel;
};
```

`MedicalPolicyCache` stores no cJSON tree after construction. It enforces the constants above and
exposes `RulesForSymptom`, `QuestionsForSymptom`, `FindQuestion`, `FindCatalogItem`, `FlagIndex`,
`SymptomIndex`, versions, validation reason, and the read-only diagnostic
`artifact_parse_count()`.

- [ ] **Step 4: Implement one-time parse and complete cross-validation**

Copy each bounded input view into a NUL-terminated `std::string`, parse it once with
`cJSON_ParseWithLengthOpts(text.c_str(), text.size() + 1, nullptr, true)`, normalize into bounded
vectors/bitsets/maps, then destroy the cJSON trees. Validate the complete
rule/interview/catalog schema currently split between `MedicalAdvisor` and `CatalogRouter`;
malformed optional predicates are invalid, never interpreted as absent.

Accept an optional integer `selection_priority` only in the range 1–65535. If multiple rules share a symptom, absent or tied priorities remain representable so `FullEvaluate` can return a safe ambiguity; file order is never recorded as priority.

Use configured array order only to assign deterministic question-scheduling priority when a question
does not contain an explicit priority; this ordering never participates in medicine selection.

- [ ] **Step 5: Repair only the mechanical antacid backup identity**

Add `recognized_non_excluding_flags` containing exactly `other_condition`,
`other_current_medicine`, and `other_drug_allergy`, and bump `rules_version` to
`rules-2026-09-23-two-stage-v1`. These values become pharmacist-reviewed input vocabulary; they are
not hardcoded bypasses. Temporarily allow this root field in the existing router validator until
Task 5 removes that duplicate parser.

Change channel 15 `strength` from `"cùng SKU channel 7"` to the exact current channel-7 string and
bump `catalog_version` to `catalog-2026-09-23-two-stage-v1`. Do not alter the channel-7 package text
or add approval metadata. Update the router regression from “repository mismatch is locked” to
“repository exact backup is accepted,” while retaining a synthetic mismatched-strength rejection.
Assert the real review remains invalid.

- [ ] **Step 6: Run cache and existing host tests**

Run both PowerShell host runners.

Expected: cache tests pass, repository antacid mapping is structurally valid, and the existing review gate still reports invalid.

- [ ] **Step 7: Commit the cache and mechanical catalog repair**

```powershell
git add main/medical/medical_policy_cache.h main/medical/medical_policy_cache.cc main/medical/tests/test_medical_policy_cache.cc data/medical_rules.json data/medicines.json main/vending/catalog_router.cc main/vending/tests/test_catalog_router.cc main/CMakeLists.txt scripts/tests/run_smartmedivend_host_tests.ps1 scripts/tests/run_smartmedivend_host_tests.sh
git diff --cached --check
git commit -m "feat: cache validated medical policy at boot"
```

