### Task 3: Add the bounded incremental medical intake session

**Files:**
- Create: `main/medical/medical_intake_session.h`
- Create: `main/medical/medical_intake_session.cc`
- Create: `main/medical/tests/test_medical_intake_session.cc`
- Modify: `main/CMakeLists.txt`
- Modify: `scripts/tests/run_smartmedivend_host_tests.ps1`
- Modify: `scripts/tests/run_smartmedivend_host_tests.sh`

**Interfaces:**
- Consumes: a turn-delta JSON string, immutable policy, and monotonic milliseconds.
- Produces: normalized one-session facts, accepted turn/facts revisions, explicit field-presence flags, bounded screening answers, and correction/expiry signals.

- [ ] **Step 1: Write failing delta/session tests**

Cover first-turn full payload, later one-answer delta, omitted-field preservation, explicit empty-array replacement, stale/decreasing turn rejection, duplicate keys, forbidden SKU/channel/stock/relay fields, 4096-byte limit, ten-minute expiry boundary, session replacement, primary-symptom correction, and new danger after an earlier safe answer.

Use a sequence such as:

```cpp
smv::MedicalIntakeSession session;
Check(session.ApplyDelta(policy,
    R"({"session_id":"s","turn_id":1,"symptoms":["mild_headache"]})", 1000).accepted,
    "first delta rejected");
Check(session.ApplyDelta(policy,
    R"({"session_id":"s","turn_id":2,"age_years":30})", 1100).accepted,
    "second delta rejected");
Check(session.facts().primary_symptom == policy.SymptomIndex("mild_headache"),
    "omitted symptom was lost");
Check(!session.ApplyDelta(policy,
    R"({"session_id":"s","turn_id":2,"relay":true})", 1200).accepted,
    "replayed forbidden turn accepted");
```

- [ ] **Step 2: Run the new test and verify the missing interface failure**

Run the medical host runner.

Expected: compilation fails on `medical_intake_session.h`.

- [ ] **Step 3: Implement normalized fixed-bound facts**

Define:

```cpp
using MedicalFactBits = std::bitset<kMaxMedicalFlags>;

struct NormalizedMedicalFacts {
    std::optional<uint8_t> age_years;
    std::optional<float> weight_kg;
    std::optional<bool> pregnancy_or_breastfeeding;
    std::optional<uint32_t> duration_hours;
    std::optional<size_t> primary_symptom;
    std::bitset<kMaxMedicalSymptoms> symptoms;
    MedicalFactBits danger_signs;
    MedicalFactBits conditions;
    MedicalFactBits current_medicines;
    MedicalFactBits drug_allergies;
    bool danger_signs_reported = false;
    bool conditions_reported = false;
    bool current_medicines_reported = false;
    bool drug_allergies_reported = false;
    std::array<int8_t, kMaxMedicalQuestions> screening_answers{};
};

struct IntakeApplyResult {
    bool accepted = false;
    bool session_replaced = false;
    bool facts_changed = false;
    std::string reason;
    std::string clarify_field;
};
```

Initialize answers to `-1`; use `0` and `1` only for explicit booleans. Enforce one active session, session ID length 1–64, turn 1–1,000,000, and 600,000 ms inactivity expiry.

- [ ] **Step 4: Implement delta merge and compatibility semantics**

Accept `primary_symptom` plus current intake fields. On the first turn, exactly one `symptoms` entry also establishes the primary symptom for compatibility; multiple symptoms without `primary_symptom` remain accepted facts but produce `clarify_field="primary_symptom"`. Present arrays replace their category; omitted arrays preserve it; `screening_answers` merges.

Accept policy-known flags plus only the sentinels declared in the policy's
`recognized_non_excluding_flags`. Return a clarification result for the literal `unknown` or an
identifier outside the approved vocabulary. Unknown object-field names and vending/control fields
remain hard input rejections.

A primary-symptom change clears only old symptom-profile answers. Any accepted fact change increments `facts_revision`; every new accepted turn updates `last_activity_ms` and invalidates a staged candidate later through the coordinator.

- [ ] **Step 5: Run all session and policy tests**

Run the medical host runner.

Expected: delta merge, expiry, correction, control-field, and bounded-input tests pass without parsing the policy again.

- [ ] **Step 6: Commit the session unit**

```powershell
git add main/medical/medical_intake_session.h main/medical/medical_intake_session.cc main/medical/tests/test_medical_intake_session.cc main/CMakeLists.txt scripts/tests/run_smartmedivend_host_tests.ps1 scripts/tests/run_smartmedivend_host_tests.sh
git diff --cached --check
git commit -m "feat: retain bounded medical turn deltas"
```

