### Task 4: Refactor MedicalAdvisor into FastScreen and FullEvaluate

**Files:**
- Modify: `main/medical/medical_advisor.h`
- Modify: `main/medical/medical_advisor.cc`
- Modify: `main/medical/tests/test_medical_advisor.cc`
- Modify: `main/vending/vending_coordinator.cc`
- Modify: `main/vending/tests/test_vending_coordinator.cc`
- Modify: `main/boards/smartmedivend-s3/smartmedivend_board.cc`
- Modify: `scripts/tests/run_smartmedivend_host_tests.ps1`
- Modify: `scripts/tests/run_smartmedivend_host_tests.sh`

**Interfaces:**
- Consumes: `MedicalPolicyCache`, `MedicalIntakeSession`, turn delta, monotonic milliseconds, and an injected microsecond clock.
- Produces: a structured `MedicalEvaluation` with exactly one next question for `ASK`, indexed fast-screen behavior, and at most one full evaluation per facts revision.

- [ ] **Step 1: Replace snapshot-oriented tests with failing two-stage tests**

Add these assertions before implementation:

```cpp
auto first = advisor.EvaluateTurn(
    R"({"session_id":"s","turn_id":1,"symptoms":["mild_headache"]})", 1000);
Check(first.decision == smv::MedicalDecision::kAsk, "missing facts did not ASK");
Check(!first.next_question_vi.empty(), "ASK dropped next_question_vi");

auto offer = CompleteMildHeadacheAsDeltas(advisor);
Check(offer.decision == smv::MedicalDecision::kOffer, "mild case did not offer");
Check(advisor.full_evaluation_count() == 1,
      "full rules were evaluated more than once for one facts revision");
Check(policy.artifact_parse_count() == 2, "static JSON reparsed during conversation");
```

Also test explicit danger, `refer_if`, `exclude_if` removing only one candidate, unrelated sentinel allergy not removing paracetamol, unknown token producing `ASK`, priority selection in a synthetic test-only policy, priority tie producing no offer, and a correction rerunning full evaluation exactly once.

- [ ] **Step 2: Run tests and verify the old API/behavior fails**

Run the medical host runner.

Expected: compilation or assertions fail because `EvaluateTurn`, structured questions, and two-stage counters do not exist.

- [ ] **Step 3: Define the structured result and advisor API**

Use:

```cpp
struct MedicalEvaluation {
    MedicalDecision decision = MedicalDecision::kDeny;
    std::string reason = "NOT_EVALUATED";
    std::string session_id;
    uint32_t turn_id = 0;
    uint32_t facts_revision = 0;
    std::string next_question_id;
    std::string next_question_vi;
    std::string missing_field;
    std::optional<MedicalOffer> offer;
    bool full_evaluation_ran = false;
    uint32_t fast_screen_us = 0;
    uint32_t full_evaluation_us = 0;
    std::string response_json;
};

class MedicalAdvisor {
public:
    using ClockUs = std::function<uint64_t()>;
    MedicalAdvisor(const MedicalPolicyCache& policy, ClockUs clock_us);
    MedicalEvaluation EvaluateTurn(std::string_view delta_json, uint64_t now_ms);
    void ResetSession();
    uint32_t facts_revision() const;
    uint32_t full_evaluation_count() const;
};
```

Keep `IntakeSchema()` and `SymptomGuide()` but render them from the cache. Remove raw `rules_`, `catalog_`, and `review_` storage.

Add one `std::unique_ptr<MedicalPolicyCache>` board member. Construct it before the advisor and pass
the same reference to `MedicalAdvisor`; keep the existing raw-JSON `CatalogRouter` construction
only until Task 5 removes its parser. Pass `esp_timer_get_time()` as the production microsecond
clock. Change the coordinator's existing evaluation call to
`advisor_.EvaluateTurn(patient_facts_json, now_ms)` and update its host fixture to construct the
cache/session-based advisor; response forwarding itself remains Task 5.

- [ ] **Step 4: Implement FastScreen with permissive uncertainty semantics**

Order checks exactly as the spec: input/session validity, explicit danger/hard population referral, missing always-required facts, indexed primary-symptom candidates, known `refer_if`, candidate-local `exclude_if`, then the highest-priority unanswered relevant symptom question.

Build derived bits deterministically from normalized facts (`weight_below_50kg`, `age_16_or_17`,
and `duration_over_48_hours`) before applying candidate predicates. Pregnancy/breastfeeding and age
below the approved scope remain explicit population referrals.

An explicit `danger_signs:[]` is the consolidated global danger confirmation; do not require all six legacy global questions after it. A `CLARIFY` mismatch and an unknown medical token return `ASK` with one Vietnamese question. Missing and silence never become false.

Use these bounded field questions when no policy question applies:

```cpp
{"primary_symptom", "Triệu chứng chính làm bạn khó chịu nhất là gì?"},
{"danger_signs", "Bạn có khó thở, đau ngực, ngất, co giật, chảy máu, đau dữ dội hoặc nặng lên nhanh không?"},
{"age_years", "Bạn bao nhiêu tuổi?"},
{"pregnancy_or_breastfeeding", "Bạn có đang mang thai hoặc cho con bú không?"},
{"duration_hours", "Triệu chứng này đã kéo dài khoảng bao lâu?"},
{"weight_kg", "Cân nặng hiện tại của bạn khoảng bao nhiêu ki-lô-gam?"},
{"conditions", "Bạn có bệnh nền nào đang điều trị không?"},
{"current_medicines", "Bạn đang dùng thuốc hoặc thực phẩm bổ sung nào không?"},
{"drug_allergies", "Bạn có dị ứng với thuốc nào không?"},
```

- [ ] **Step 5: Implement FullEvaluate and per-revision caching**

Evaluate only `policy.RulesForSymptom(primary)`. A `refer_if` produces `REFER`; an `exclude_if` removes that rule; another remaining rule may still win. Select one remaining rule only if it is unique or has a unique pharmacist-authored priority. A tie returns `REFER` unless the cache exposes a configured discriminator question, in which case return `ASK`.

Cache the full result by `{session_id, turn_id, facts_revision, rules_version, catalog_version}`. The evaluation returns a canonical ID and display identity only, never SKU/channel. Serialize `ASK` with `next_question_id`, `next_question_vi`, and `vend_allowed:false`.

- [ ] **Step 6: Add bounded timing instrumentation**

Measure fast and full stages with the injected `ClockUs`; do not log medical facts. Tests use a deterministic clock and assert one full-stage timing sample per facts revision. Board logging is added in Task 7.

- [ ] **Step 7: Run medical/vending suites and compile the development board**

Run both PowerShell host runners, then:

```powershell
$env:PYTHONUTF8='1'
$env:PATH='C:\Espressif\tools\python\v6.1\venv\Scripts;' + $env:PATH
. 'C:\esp\v6.1\esp-idf\export.ps1'
& 'C:\Espressif\python_env\idf6.1_py3.14_env\Scripts\python.exe' scripts/build.py smartmedivend-s3 --name smartmedivend-s3
```

Run the medical suite a second time after repeating a completed turn sequence.

Expected: both host runs and the board build pass; parse count stays two, incomplete mild cases
remain `ASK`, and completed mild cases return a structured offer.

- [ ] **Step 8: Commit the two-stage advisor**

```powershell
git add main/medical/medical_advisor.h main/medical/medical_advisor.cc main/medical/tests/test_medical_advisor.cc main/vending/vending_coordinator.cc main/vending/tests/test_vending_coordinator.cc main/boards/smartmedivend-s3/smartmedivend_board.cc scripts/tests/run_smartmedivend_host_tests.ps1 scripts/tests/run_smartmedivend_host_tests.sh
git diff --cached --check
git commit -m "feat: evaluate medical intake in two stages"
```

