#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

// M5Stack Cardputer Adv Board configuration
// MCU: ESP32-S3FN8 (Stamp-S3A)
// Display: ST7789V2 1.14" 240x135
// Audio: ES8311 + NS4150B

#include <driver/gpio.h>

// Audio settings
#define AUDIO_INPUT_SAMPLE_RATE  24000
#define AUDIO_OUTPUT_SAMPLE_RATE 24000

// I2S Audio pins (ES8311)
#define AUDIO_I2S_GPIO_MCLK GPIO_NUM_NC
#define AUDIO_I2S_GPIO_BCLK GPIO_NUM_41   // SCLK
#define AUDIO_I2S_GPIO_WS   GPIO_NUM_43   // LRCK
#define AUDIO_I2S_GPIO_DOUT GPIO_NUM_42   // DSDIN (MCU -> ES8311)
#define AUDIO_I2S_GPIO_DIN  GPIO_NUM_46   // ASDOUT (ES8311 -> MCU)

// I2C pins (shared for ES8311, TCA8418, BMI270)
#define AUDIO_CODEC_I2C_SDA_PIN  GPIO_NUM_8
#define AUDIO_CODEC_I2C_SCL_PIN  GPIO_NUM_9
#define AUDIO_CODEC_ES8311_ADDR  ES8311_CODEC_DEFAULT_ADDR
#define AUDIO_CODEC_PA_PIN       GPIO_NUM_NC  // NS4150B is always on

// Button
#define BOOT_BUTTON_GPIO        GPIO_NUM_0
#define BUILTIN_LED_GPIO        GPIO_NUM_NC
#define VOLUME_UP_BUTTON_GPIO   GPIO_NUM_NC
#define VOLUME_DOWN_BUTTON_GPIO GPIO_NUM_NC

// Display ST7789V2 (SPI)
#define DISPLAY_WIDTH   240
#define DISPLAY_HEIGHT  135
#define DISPLAY_MIRROR_X true
#define DISPLAY_MIRROR_Y false
#define DISPLAY_SWAP_XY true

#define DISPLAY_OFFSET_X  40
#define DISPLAY_OFFSET_Y  53

#define DISPLAY_SPI_MOSI_PIN GPIO_NUM_35
#define DISPLAY_SPI_SCLK_PIN GPIO_NUM_36
#define DISPLAY_SPI_CS_PIN   GPIO_NUM_37
#define DISPLAY_DC_PIN       GPIO_NUM_34
#define DISPLAY_RST_PIN      GPIO_NUM_33
#define DISPLAY_BACKLIGHT_PIN GPIO_NUM_38
#define DISPLAY_BACKLIGHT_OUTPUT_INVERT false

// Keyboard TCA8418 I2C address and interrupt pin
#define KEYBOARD_TCA8418_ADDR 0x34
#define KEYBOARD_INT_PIN      GPIO_NUM_11

// IMU BMI270 I2C address
#define IMU_BMI270_ADDR 0x68

// Battery monitoring (ADC voltage divider on GPIO 10 / ADC1_CH9)
// Verified from Cardputer-Adv schematic (Sch_M5CardputerAdv_v1.0):
// R9 = 100KΩ (BAT+ to GPIO10), R8 = 100KΩ (GPIO10 to GND)
#define BATTERY_ADC_UNIT        ADC_UNIT_1
#define BATTERY_ADC_CHANNEL     ADC_CHANNEL_9
#define BATTERY_UPPER_RESISTOR  100000.0f
#define BATTERY_LOWER_RESISTOR  100000.0f
#define BATTERY_CHARGING_PIN    GPIO_NUM_NC

#endif // _BOARD_CONFIG_H_
