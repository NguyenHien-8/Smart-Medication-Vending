#pragma once

#include <cstddef>
#include <cstdint>

// SmartMediVend INMP441-only, bounded PCM conditioning. Pure C++ to permit
// host-side boundary tests. No hardware gain is available on this I2S mic.
// The input conversion retains the existing Xiaozhi 32-bit I2S >>12 scale.
namespace smv {
class MicProcessor {
public:
    struct FrameStats {
        uint32_t mean_abs_before = 0;
        uint32_t mean_abs_after = 0;
        uint32_t peak_before = 0;
        uint32_t clipped_input = 0;
        uint32_t clipped_output = 0;
        uint16_t gain_q8 = 256;
    };

    void Reset() {
        dc_estimate_ = 0;
        gain_q8_ = 256;
    }

    FrameStats Process(const int32_t* raw, int16_t* pcm, size_t samples) {
        FrameStats stats;
        if (raw == nullptr || pcm == nullptr || samples == 0) {
            return stats;
        }
        uint64_t sum_abs = 0;
        for (size_t i = 0; i < samples; ++i) {
            const int32_t shifted = raw[i] >> 12;  // Match NoAudioCodec::Read.
            const int32_t sample = Clamp16(shifted);
            if (shifted != sample) ++stats.clipped_input;
            // Fixed-point DC removal (~10 Hz at 16 kHz); no frame-edge jump.
            dc_estimate_ += (sample - dc_estimate_) / 256;
            const int32_t filtered = sample - dc_estimate_;
            const int32_t clean = Clamp16(filtered);
            pcm[i] = static_cast<int16_t>(clean);
            const uint32_t magnitude = Abs16(clean);
            sum_abs += magnitude;
            if (magnitude > stats.peak_before) stats.peak_before = magnitude;
        }
        stats.mean_abs_before = static_cast<uint32_t>(sum_abs / samples);

        // Quiet-room noise must never be amplified to the speech target.
        uint32_t desired = 256;
        if (stats.mean_abs_before >= 120) {
            desired = (4500U * 256U) / stats.mean_abs_before;
            if (desired < 256) desired = 256;
            if (desired > 768) desired = 768;  // Maximum +9.5 dB.
            // Peak-aware limit prevents gain from turning clear speech into clipping.
            if (stats.peak_before > 0) {
                const uint32_t peak_limited = (28000U * 256U) / stats.peak_before;
                if (desired > peak_limited) desired = peak_limited;
                if (desired < 256) desired = 256;
            }
        }
        // Attack/release per 10-ms input block: gain rises gradually, falls
        // quickly after a louder frame. No VAD gate or frame dropping.
        if (gain_q8_ < desired) {
            const uint32_t rise = desired - gain_q8_;
            gain_q8_ += static_cast<uint16_t>(rise > 8 ? 8 : rise);
        } else if (gain_q8_ > desired) {
            const uint32_t fall = gain_q8_ - desired;
            gain_q8_ -= static_cast<uint16_t>(fall > 64 ? 64 : fall);
        }
        stats.gain_q8 = gain_q8_;
        uint64_t sum_out = 0;
        for (size_t i = 0; i < samples; ++i) {
            const int32_t scaled = (static_cast<int32_t>(pcm[i]) * gain_q8_) / 256;
            const int32_t limited = Clamp16(scaled);
            if (limited != scaled) ++stats.clipped_output;
            pcm[i] = static_cast<int16_t>(limited);
            sum_out += Abs16(limited);
        }
        stats.mean_abs_after = static_cast<uint32_t>(sum_out / samples);
        return stats;
    }

private:
    static int32_t Clamp16(int32_t v) {
        if (v > 32767) return 32767;
        if (v < -32768) return -32768;
        return v;
    }
    static uint32_t Abs16(int32_t v) {
        return static_cast<uint32_t>(v < 0 ? -v : v);
    }
    int32_t dc_estimate_ = 0;
    uint16_t gain_q8_ = 256;
};
}  // namespace smv
